"""
客户管理服务

封装客户相关的所有业务逻辑：
- 创建客户
- 查询客户列表
- 查询客户详情
- 软删除客户
"""
import uuid
from datetime import datetime
from typing import Optional, List

from sqlalchemy import select, and_, or_, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.customer import Customer
from app.schemas.customer import CustomerCreate, CustomerListItem, CustomerDetail, CustomerListResponse


class CustomerService:
    """
    客户服务类
    
    所有客户相关业务逻辑封装在此类中
    """
    
    def __init__(self, session: AsyncSession):
        """
        初始化服务
        
        Args:
            session: 数据库会话
        """
        self.session = session
    
    async def create_customer(
        self,
        user_id: str,
        data: CustomerCreate,
    ) -> str:
        """
        创建新客户
        
        Args:
            user_id: 当前用户ID
            data: 创建客户请求数据
            
        Returns:
            新创建客户的ID
        """
        # 生成 UUID
        customer_id = str(uuid.uuid4())
        
        # 创建客户实体
        customer = Customer(
            id=customer_id,
            user_id=user_id,
            name=data.name.strip(),
            phone=data.phone.strip() if data.phone else None,
            gender=data.gender.strip() if data.gender else None,
            tags=data.tags if data.tags else [],
            summary_status="stale",
            deleted_at=None,
        )
        
        self.session.add(customer)
        await self.session.flush()
        
        return customer_id
    
    async def get_customer_list(
        self,
        user_id: str,
        keyword: Optional[str] = None,
    ) -> CustomerListResponse:
        """
        获取客户列表
        
        Args:
            user_id: 当前用户ID
            keyword: 搜索关键词（按姓名模糊匹配）
            
        Returns:
            客户列表响应
        """
        # 构建基础查询：未删除 + 属于当前用户
        query = select(Customer).where(
            and_(
                Customer.user_id == user_id,
                Customer.deleted_at.is_(None)
            )
        )
        
        # 如果有搜索关键词，添加姓名模糊匹配
        if keyword and keyword.strip():
            keyword_clean = keyword.strip()
            query = query.where(
                Customer.name.ilike(f"%{keyword_clean}%")
            )
        
        # 按更新时间倒序
        query = query.order_by(Customer.updated_at.desc())
        
        # 执行查询
        result = await self.session.execute(query)
        customers = result.scalars().all()
        
        # 转换为响应 Schema
        items = [
            CustomerListItem(
                id=c.id,
                name=c.name,
                phone=c.phone,
                tags=c.tags,
                updated_at=c.updated_at,
            )
            for c in customers
        ]
        
        return CustomerListResponse(
            items=items,
            total=len(items),
        )
    
    async def get_customer_detail(
        self,
        user_id: str,
        customer_id: str,
    ) -> Optional[CustomerDetail]:
        """
        获取客户详情
        
        Args:
            user_id: 当前用户ID
            customer_id: 客户ID
            
        Returns:
            客户详情，如果不存在或已删除则返回 None
        """
        query = select(Customer).where(
            and_(
                Customer.id == customer_id,
                Customer.user_id == user_id,
                Customer.deleted_at.is_(None)
            )
        )
        
        result = await self.session.execute(query)
        customer = result.scalar_one_or_none()
        
        if not customer:
            return None
        
        return CustomerDetail(
            id=customer.id,
            name=customer.name,
            phone=customer.phone,
            gender=customer.gender,
            tags=customer.tags,
            summary_status=customer.summary_status,
            created_at=customer.created_at,
            updated_at=customer.updated_at,
        )
    
    async def delete_customer(
        self,
        user_id: str,
        customer_id: str,
    ) -> bool:
        """
        软删除客户
        
        Args:
            user_id: 当前用户ID
            customer_id: 要删除的客户ID
            
        Returns:
            是否删除成功（客户不存在或已删除返回 False）
        """
        # 先查询确认客户存在且未删除
        query = select(Customer).where(
            and_(
                Customer.id == customer_id,
                Customer.user_id == user_id,
                Customer.deleted_at.is_(None)
            )
        )
        
        result = await self.session.execute(query)
        customer = result.scalar_one_or_none()
        
        if not customer:
            return False
        
        # 软删除：更新 deleted_at 字段
        customer.deleted_at = datetime.utcnow()
        await self.session.flush()
        
        return True
